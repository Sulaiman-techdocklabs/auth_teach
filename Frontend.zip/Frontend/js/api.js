﻿export const taskAPI = {

    getTasks() {
        return apiRequest("/tasks");
    },

    createTask(data) {
        return apiRequest("/tasks", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },

    updateTask(id, data) {
        return apiRequest(`/tasks/${id}`, {
            method: "PUT",
            body: JSON.stringify(data)
        });
    },

    deleteTask(id) {
        return apiRequest(`/tasks/${id}`, {
            method: "DELETE"
        });
    }

};