﻿import { taskAPI } from "./api.js";
import { checkAuth, handleLogout, showToast } from "./utils.js";

checkAuth();

document
    .getElementById("logoutBtn")
    .addEventListener("click", handleLogout);

const table = document.getElementById("recentTasksTable");

loadDashboard();

async function loadDashboard() {

    showLoading();

    try {

        const response = await taskAPI.getTasks();

        const tasks = response.data || [];

        updateStatistics(tasks);

        renderRecentTasks(tasks);

    } catch (error) {

        console.error(error);

        table.innerHTML = `
            <tr>
                <td colspan="3" class="table-empty">
                    ⚠ Unable to load tasks
                </td>
            </tr>
        `;

        if (showToast) {
            showToast("Unable to load dashboard", "error");
        }

    }

}

/* ===========================
        Statistics
=========================== */

function updateStatistics(tasks) {

    document.getElementById("totalTasks").textContent =
        tasks.length;

    document.getElementById("pendingTasks").textContent =
        tasks.filter(
            t => t.status === "Pending"
        ).length;

    document.getElementById("completedTasks").textContent =
        tasks.filter(
            t => t.status === "Completed"
        ).length;

    document.getElementById("highPriorityTasks").textContent =
        tasks.filter(
            t => t.priority === "High"
        ).length;

}

/* ===========================
      Recent Tasks
=========================== */

function renderRecentTasks(tasks) {

    table.innerHTML = "";

    if (!tasks.length) {

        table.innerHTML = `
            <tr>

                <td colspan="3" class="table-empty">

                    <div class="empty-state">

                        <div class="emoji">
                            📋
                        </div>

                        <h3>
                            No Tasks Yet
                        </h3>

                        <p>
                            Start by creating your first task.
                        </p>

                    </div>

                </td>

            </tr>
        `;

        return;

    }

    tasks
        .slice(0, 5)
        .forEach(task => {

            table.innerHTML += `

                <tr>

                    <td>

                        <div class="task-title">

                            ${task.title}

                        </div>

                    </td>

                    <td>

                        ${priorityBadge(task.priority)}

                    </td>

                    <td>

                        ${statusBadge(task.status)}

                    </td>

                </tr>

            `;

        });

}

/* ===========================
       Loading
=========================== */

function showLoading() {

    table.innerHTML = "";

    for (let i = 0; i < 5; i++) {

        table.innerHTML += `

            <tr>

                <td>
                    <div class="skeleton"></div>
                </td>

                <td>
                    <div class="skeleton small"></div>
                </td>

                <td>
                    <div class="skeleton small"></div>
                </td>

            </tr>

        `;

    }

}

/* ===========================
      Status Badge
=========================== */

function statusBadge(status) {

    switch (status) {

        case "Completed":

            return `
                <span class="badge badge-success">
                    ✓ Completed
                </span>
            `;

        case "Pending":

            return `
                <span class="badge badge-warning">
                    ⏳ Pending
                </span>
            `;

        default:

            return `
                <span class="badge">
                    ${status}
                </span>
            `;

    }

}

/* ===========================
     Priority Badge
=========================== */

function priorityBadge(priority) {

    switch (priority) {

        case "High":

            return `
                <span class="badge badge-danger">
                    🔥 High
                </span>
            `;

        case "Medium":

            return `
                <span class="badge badge-primary">
                    ⚡ Medium
                </span>
            `;

        case "Low":

            return `
                <span class="badge badge-success">
                    🌿 Low
                </span>
            `;

        default:

            return `
                <span class="badge">
                    ${priority}
                </span>
            `;

    }

}