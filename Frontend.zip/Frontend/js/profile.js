import { authAPI } from "./api.js";
import {
    checkAuth,
    handleLogout,
    showToast
} from "./utils.js";

checkAuth();

document
    .getElementById("logoutBtn")
    .addEventListener(
        "click",
        handleLogout
    );

loadProfile();

async function loadProfile() {

    try {

        const response =
            await authAPI.getProfile();

        const user =
            response.data;

        document.getElementById("name").textContent =
            user.name;

        document.getElementById("email").textContent =
            user.email;

        document.getElementById("verified").innerHTML =
            user.isVerified

                ? `<span class="badge badge-success">
                        ✓ Verified
                   </span>`

                : `<span class="badge badge-warning">
                        Pending Verification
                   </span>`;

        document.getElementById("joined").textContent =
            new Date(
                user.createdAt
            ).toLocaleDateString(
                "en-IN",
                {
                    day: "2-digit",
                    month: "long",
                    year: "numeric"
                }
            );

        document.getElementById("avatar")
            .textContent =
            user.name
                .charAt(0)
                .toUpperCase();

    } catch (err) {

        console.error(err);

        showToast?.(
            "Unable to load profile.",
            "error"
        );

    }

}