import { taskAPI } from "./api.js";
import {
    checkAuth,
    handleLogout,
    showToast
} from "./utils.js";

checkAuth();

/* ==========================
        DOM ELEMENTS
========================== */

const form = document.getElementById("taskForm");
const table = document.getElementById("taskTable");

const taskId = document.getElementById("taskId");

const titleInput = document.getElementById("title");
const descriptionInput = document.getElementById("description");
const priorityInput = document.getElementById("priority");
const dueDateInput = document.getElementById("dueDate");

const searchInput = document.getElementById("searchTask");

const submitButton =
    form.querySelector("button");

document
    .getElementById("logoutBtn")
    .addEventListener(
        "click",
        handleLogout
    );

/* ==========================
          STATE
========================== */

let tasks = [];

let filteredTasks = [];

let editingTask = null;

/* ==========================
      INITIAL LOAD
========================== */

loadTasks();

/* ==========================
      SEARCH TASK
========================== */

searchInput.addEventListener("input", e => {

    const keyword =
        e.target.value
            .trim()
            .toLowerCase();

    filteredTasks = tasks.filter(task => {

        return (

            task.title
                .toLowerCase()
                .includes(keyword)

            ||

            task.description
                .toLowerCase()
                .includes(keyword)

            ||

            task.priority
                .toLowerCase()
                .includes(keyword)

            ||

            task.status
                .toLowerCase()
                .includes(keyword)

        );

    });

    renderTable(filteredTasks);

});

/* ==========================
    CREATE / UPDATE TASK
========================== */

form.addEventListener(
    "submit",
    async e => {

        e.preventDefault();

        const data = {

            title:
                titleInput.value.trim(),

            description:
                descriptionInput.value.trim(),

            priority:
                priorityInput.value,

            dueDate:
                dueDateInput.value

        };

        if (!data.title) {

            showToast?.(
                "Task title is required.",
                "error"
            );

            return;

        }

        submitButton.disabled = true;

        submitButton.innerHTML = `
            <i class="fa-solid fa-spinner fa-spin"></i>
            Saving...
        `;

        try {

            if (editingTask) {

                await taskAPI.updateTask(
                    editingTask,
                    data
                );

                showToast?.(
                    "Task updated successfully",
                    "success"
                );

            } else {

                await taskAPI.createTask(
                    data
                );

                showToast?.(
                    "Task created successfully",
                    "success"
                );

            }

            resetForm();

            await loadTasks();

        } catch (err) {

            console.error(err);

            showToast?.(
                err.message ||
                "Unable to save task.",
                "error"
            );

        } finally {

            submitButton.disabled = false;

            submitButton.innerHTML = `
                <i class="fa-solid fa-floppy-disk"></i>
                Save Task
            `;

        }

    }
);

/* ==========================
      LOAD TASKS
========================== */

async function loadTasks() {

    try {

        table.innerHTML = "";

        for (let i = 0; i < 5; i++) {

            table.innerHTML += `

                <tr>

                    <td>
                        <div class="skeleton"></div>
                    </td>

                    <td>
                        <div class="skeleton small"></div>
                    </td>

                    <td>
                        <div class="skeleton small"></div>
                    </td>

                    <td>
                        <div class="skeleton small"></div>
                    </td>

                    <td>
                        <div class="skeleton small"></div>
                    </td>

                </tr>

            `;

        }

        const response =
            await taskAPI.getTasks();

        tasks =
            response.data || [];

        filteredTasks =
            [...tasks];

        renderTable(filteredTasks);

    } catch (err) {

        console.error(err);

        showToast?.(
            "Unable to load tasks",
            "error"
        );

    }

}


/* ==========================
        RENDER TABLE
========================== */

function renderTable(taskList) {

    table.innerHTML = "";

    if (!taskList.length) {

        table.innerHTML = `

            <tr>

                <td colspan="5" class="table-empty">

                    <div class="empty-state">

                        <div class="emoji">
                            📋
                        </div>

                        <h3>
                            No Tasks Found
                        </h3>

                        <p>
                            Create your first task or try another search.
                        </p>

                    </div>

                </td>

            </tr>

        `;

        return;

    }

    taskList.forEach(task => {

        table.innerHTML += createTaskRow(task);

    });

}

/* ==========================
        TABLE ROW
========================== */

function createTaskRow(task) {

    return `

        <tr>

            <td>

                <div class="task-name">

                    <strong>

                        ${escapeHTML(task.title)}

                    </strong>

                    <span>

                        ${escapeHTML(
                            task.description || "No description"
                        )}

                    </span>

                </div>

            </td>

            <td>

                ${priorityBadge(task.priority)}

            </td>

            <td>

                ${statusBadge(task.status)}

            </td>

            <td>

                <span class="date">

                    ${formatDate(task.dueDate)}

                </span>

            </td>

            <td>

                <div class="action-buttons">

                    <button
                        class="edit-btn"
                        onclick="editTask('${task._id}')"
                        title="Edit Task">

                        <i class="fa-solid fa-pen"></i>

                    </button>

                    <button
                        class="delete-btn"
                        onclick="deleteTask('${task._id}')"
                        title="Delete Task">

                        <i class="fa-solid fa-trash"></i>

                    </button>

                </div>

            </td>

        </tr>

    `;

}

/* ==========================
      PRIORITY BADGES
========================== */

function priorityBadge(priority) {

    switch (priority) {

        case "High":

            return `
                <span class="badge badge-danger">
                    🔥 High
                </span>
            `;

        case "Medium":

            return `
                <span class="badge badge-primary">
                    ⚡ Medium
                </span>
            `;

        case "Low":

            return `
                <span class="badge badge-success">
                    🌿 Low
                </span>
            `;

        default:

            return `
                <span class="badge">
                    ${priority}
                </span>
            `;

    }

}

/* ==========================
        STATUS BADGES
========================== */

function statusBadge(status) {

    switch (status) {

        case "Completed":

            return `
                <span class="badge badge-success">
                    ✓ Completed
                </span>
            `;

        case "Pending":

            return `
                <span class="badge badge-warning">
                    ⏳ Pending
                </span>
            `;

        case "In Progress":

            return `
                <span class="badge badge-primary">
                    🚀 In Progress
                </span>
            `;

        default:

            return `
                <span class="badge">
                    ${status}
                </span>
            `;

    }

}

/* ==========================
        DATE FORMAT
========================== */

function formatDate(date) {

    if (!date) return "-";

    return new Date(date)
        .toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );

}

/* ==========================
        ESCAPE HTML
========================== */

function escapeHTML(str = "") {

    return str

        .replace(/&/g, "&amp;")

        .replace(/</g, "&lt;")

        .replace(/>/g, "&gt;")

        .replace(/"/g, "&quot;")

        .replace(/'/g, "&#39;");

}

/* ==========================
        EDIT TASK
========================== */

function editTask(id) {

    const task = tasks.find(t => t._id === id);

    if (!task) return;

    editingTask = id;

    taskId.value = id;

    titleInput.value = task.title || "";
    descriptionInput.value = task.description || "";
    priorityInput.value = task.priority || "Medium";
    dueDateInput.value = task.dueDate
        ? task.dueDate.substring(0, 10)
        : "";

    submitButton.innerHTML = `
        <i class="fa-solid fa-pen"></i>
        Update Task
    `;

    let cancelBtn = document.getElementById("cancelEditBtn");

    if (!cancelBtn) {

        cancelBtn = document.createElement("button");

        cancelBtn.type = "button";
        cancelBtn.id = "cancelEditBtn";
        cancelBtn.className = "secondary-btn";

        cancelBtn.innerHTML = `
            <i class="fa-solid fa-xmark"></i>
            Cancel
        `;

        cancelBtn.addEventListener(
            "click",
            resetForm
        );

        submitButton.insertAdjacentElement(
            "afterend",
            cancelBtn
        );

    }

    titleInput.focus();

    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });

}

/* ==========================
        DELETE TASK
========================== */

async function deleteTask(id) {

    const confirmed = confirm(
        "Delete this task?"
    );

    if (!confirmed) return;

    try {

        await taskAPI.deleteTask(id);

        showToast?.(
            "Task deleted successfully",
            "success"
        );

        if (editingTask === id) {

            resetForm();

        }

        await loadTasks();

    } catch (err) {

        console.error(err);

        showToast?.(
            err.message ||
            "Unable to delete task",
            "error"
        );

    }

}

/* ==========================
        RESET FORM
========================== */

function resetForm() {

    editingTask = null;

    form.reset();

    taskId.value = "";

    priorityInput.value = "Medium";

    submitButton.innerHTML = `
        <i class="fa-solid fa-floppy-disk"></i>
        Save Task
    `;

    const cancelBtn =
        document.getElementById(
            "cancelEditBtn"
        );

    if (cancelBtn) {

        cancelBtn.remove();

    }

}

/* ==========================
        OPTIONAL
========================== */

window.editTask = editTask;

window.deleteTask = deleteTask;